#include <stdio.h>

#if defined(HAVE_FREEGLUT)

#ifdef WIN32
#include "../include/GL/freeglut.h"
#else
#include <GL/freeglut.h>
#endif

#define OGL_FREEGLUT_VERSION_EXPR glutGet(GLUT_VERSION)

#else

#define OGL_FREEGLUT_VERSION_EXPR -1

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#endif

#define PROGRAM "glversion"

int main(int argc, char **argv)
{
  char *version = NULL;
  char *vendor = NULL;
  char *renderer = NULL;
  char *extensions = NULL;
  GLuint idWindow = 0;
  int	freeglutVersion;

  glutInit(&argc, argv);
  glutInitWindowSize(1,1);
  glutInitDisplayMode(GLUT_RGBA);
  idWindow = glutCreateWindow(PROGRAM);
  glutHideWindow();

  version =     (char*)glGetString(GL_VERSION);
  vendor =      (char*)glGetString(GL_VENDOR);
  renderer =    (char*)glGetString(GL_RENDERER);
  extensions =  (char*)glGetString(GL_EXTENSIONS);

  freeglutVersion = OGL_FREEGLUT_VERSION_EXPR;
  if(freeglutVersion != -1) {
    printf("FREEGLUT=%d\n", freeglutVersion);
  }
  printf("GLUT=%d\n", GLUT_API_VERSION);

  printf("VERSION=%s\nVENDOR=%s\nRENDERER=%s\nEXTENSIONS=%s\n", version, vendor, renderer, extensions);

  glutDestroyWindow(idWindow);
  return(0);
}
